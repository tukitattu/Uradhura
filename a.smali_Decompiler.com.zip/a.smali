###### Class a0.a (a0.a)
.class public final synthetic La0/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:La0/c;

.field public final synthetic c:LR/f;


# direct methods
.method public synthetic constructor <init>(La0/c;LR/f;I)V
    .registers 4

    .line 1
    iput p3, p0, La0/a;->a:I

    iput-object p1, p0, La0/a;->b:La0/c;

    iput-object p2, p0, La0/a;->c:LR/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, La0/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_2e

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La0/a;->b:La0/c;

    .line 7
    .line 8
    invoke-virtual {v0}, La0/c;->f()Ljava/util/concurrent/Executor;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    new-instance v2, La0/b;

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    iget-object v4, p0, La0/a;->c:LR/f;

    .line 16
    .line 17
    invoke-direct {v2, v0, v4, v3}, La0/b;-><init>(La0/c;LR/f;I)V

    .line 18
    .line 19
    .line 20
    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 21
    .line 22
    .line 23
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 24
    .line 25
    return-object v0

    .line 26
    :pswitch_19
    iget-object v0, p0, La0/a;->b:La0/c;

    .line 27
    .line 28
    invoke-virtual {v0}, La0/c;->f()Ljava/util/concurrent/Executor;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    new-instance v2, La0/b;

    .line 33
    .line 34
    const/4 v3, 0x2

    .line 35
    iget-object v4, p0, La0/a;->c:LR/f;

    .line 36
    .line 37
    invoke-direct {v2, v0, v4, v3}, La0/b;-><init>(La0/c;LR/f;I)V

    .line 38
    .line 39
    .line 40
    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 41
    .line 42
    .line 43
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 44
    .line 45
    return-object v0

    .line 46
    nop

    .line 47
    :pswitch_data_2e
    .packed-switch 0x0
        :pswitch_19
    .end packed-switch
.end method
