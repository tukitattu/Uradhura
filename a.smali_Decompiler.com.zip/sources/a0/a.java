package a0;

import R.f;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* JADX INFO: loaded from: /tmp/decompiler/b4c61e9aea1a4212a7346bb558566de7/classes.dex */
public final /* synthetic */ class a implements Function0 {
    public final /* synthetic */ int a;
    public final /* synthetic */ c b;
    public final /* synthetic */ f c;

    public /* synthetic */ a(c cVar, f fVar, int i) {
        this.a = i;
        this.b = cVar;
        this.c = fVar;
    }

    public final Object invoke() {
        switch (this.a) {
            case 0:
                c cVar = this.b;
                cVar.f().execute(new b(cVar, this.c, 2));
                break;
            default:
                c cVar2 = this.b;
                cVar2.f().execute(new b(cVar2, this.c, 0));
                break;
        }
        return Unit.INSTANCE;
    }
}
